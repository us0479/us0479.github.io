# Codex 최종 조립 변경 기록

- 기준: Cloud private C1 보존본 + Claude CP3. CP3 압축/파일별 SHA·단독문서·사이트 패키지 대조142검사 통과. 원본 업로드는 변경하지 않았다.
- 재사용: runtime37, ERD PDF·XLSX·데이터 사전 byte-identical. 시나리오는 Claude v1.11을 그대로 사용.
- private에 반영: 시나리오, 등록문 MD/TXT, Claude 변경/인계/상태/재개 기록, SQL감사도구5개와 공개요약1개. 원문 공개로그는 다시 넣지 않았다.
- private만 추가 변경: README의 현재 상태/과거기록 구분. scripts/verify-manifest.py에 schema1.5 처리 추가(기존 schema1.4 검증 유지), scripts/package-source.py에 새 문서·도구 선택/셸실행권한 및 기록 버전 구분. private manifest의 현재 inventory66과 C1 원문 보존blob 및 문서해시 갱신. 현재 manifest의 evidence_runs=0은 이번 포장이 새 업무실행 증거가 아니라는 의미이며 이전 Windows 증거는 내장된 C1에 그대로 있다. 이번 새 PG실행은 외부 FINAL_VALIDATION.json이 기록한다.
- 추가: 발표 제작 프롬프트와 입력안내. 600초예산, 선택이유/DB필요성/요구→코드·SQL·증거, 9장PPTX·대본·PDF·검토표 산출물을 명시.
- 공개: CP3 공개 소스 ZIP은 SHA를 유지. 홈페이지에 최종공개묶음과 발표프롬프트 링크, 최신 Codex검증 요약 추가. v1.10 소스 ZIP은 예상SHA 일치 후 활성 경로에서 제거. 개인 소개·탐색·체험assets 유지. 감사원문은 공개하지 않음.
- 검증: private current/추출본manifest, backwardcompat, 잘못된 입력4종 거부, 함수길이최대60, Java21 Maven validate/package, 새PostgreSQL16.16 postgres-it10/0/0/0. Pages 로컬브라우저35통과. 배포후 증거는 별도 영수증에 기록.
- 미실행: 이번 Windows 적용·WindowsHTTP 재실행·전체Compose기동·LMS제출·실제발표낭독. 보존B2실행을 새실행이라고 고쳐 쓰지 않음.
